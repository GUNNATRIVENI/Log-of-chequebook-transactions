import tkinter as tk
from tkinter import simpledialog, messagebox
from PIL import Image, ImageTk
import datetime

class BankAccount:
    def __init__(self, initial_balance):
        self.balance = initial_balance
        self.transactions = []

    def add_transaction(self, amount, transaction_type, date):
        previous_balance = self.balance
        if transaction_type == "DB":
            self.balance -= amount
        elif transaction_type == "CR":
            self.balance += amount
        self.transactions.append((previous_balance, amount, transaction_type, date, self.balance))

    def apply_service_charges(self):
        num_checks = sum(1 for t in self.transactions if t[2] == "DB")
        charge = 0.12 * num_checks
        if self.balance < 500:
            previous_balance = self.balance
            self.balance -= charge
            self.transactions.append((previous_balance, charge, "SC", datetime.datetime.now().strftime("%m%d%y"), self.balance))

    def print_log_book(self):
        log = "Log Book:\n"
        for t in self.transactions:
            log += f"Previous balance: {t[0]:.2f}  {t[1]:.2f} {t[2]}  New balance: {t[4]:.2f}\n"
        log += f"FINAL BALANCE: {self.balance:.2f}\n"
        messagebox.showinfo("Log Book", log)

class BankGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Bank Accounting System")
        self.root.attributes('-fullscreen', True)  # Set window to fullscreen
        self.accounts = {}
        self.create_widgets()

    def create_widgets(self):
        # Load and set the background image
        bg_image = Image.open("/home/vaishnavi/coding practice/wise/bank_background.jpg")
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        bg_image = bg_image.resize((screen_width, screen_height), Image.Resampling.LANCZOS)
        bg_photo = ImageTk.PhotoImage(bg_image)

        self.bg_label = tk.Label(self.root, image=bg_photo)
        self.bg_label.image = bg_photo  # Keep a reference
        self.bg_label.place(relwidth=1, relheight=1)

        # Add start button at the center
        self.start_button = tk.Button(self.root, text="Start", command=self.start_program, font=("Helvetica", 14), bg="blue", fg="white")
        self.start_button.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

    def start_program(self):
        # Remove start button and display accountant and customer images
        self.start_button.place_forget()

        # Load and place accountant image
        acc_image = Image.open("/home/vaishnavi/coding practice/wise/accountant.jpg")
        acc_image = acc_image.resize((150, 150), Image.Resampling.LANCZOS)
        acc_photo = ImageTk.PhotoImage(acc_image)

        self.acc_label = tk.Label(self.root, image=acc_photo)
        self.acc_label.image = acc_photo  # Keep a reference
        self.acc_label.place(relx=0.1, rely=0.9, anchor=tk.S)

        # Load and place customer image
        cust_image = Image.open("/home/vaishnavi/coding practice/wise/customer.jpg")
        cust_image = cust_image.resize((150, 150), Image.Resampling.LANCZOS)
        cust_photo = ImageTk.PhotoImage(cust_image)

        self.cust_label = tk.Label(self.root, image=cust_photo)
        self.cust_label.image = cust_photo  # Keep a reference
        self.cust_label.place(relx=0.9, rely=0.9, anchor=tk.S)

        # Add option buttons
        button_style = {"font": ("Helvetica", 14), "bg": "green", "fg": "white", "width": 20, "height": 2}

        self.new_user_button = tk.Button(self.root, text="New User", command=self.new_user, **button_style)
        self.new_user_button.place(relx=0.3, rely=0.6, anchor=tk.CENTER)

        self.transaction_button = tk.Button(self.root, text="Transaction", command=self.perform_transaction, **button_style)
        self.transaction_button.place(relx=0.5, rely=0.6, anchor=tk.CENTER)

        self.log_button = tk.Button(self.root, text="Check Log Book", command=self.check_log, **button_style)
        self.log_button.place(relx=0.7, rely=0.6, anchor=tk.CENTER)

    def new_user(self):
        user_name = simpledialog.askstring("New User", "Enter user name:")
        if user_name:
            initial_balance = simpledialog.askfloat("New User", "Enter initial balance:")
            if initial_balance is not None:
                self.accounts[user_name] = BankAccount(initial_balance)
                messagebox.showinfo("New User", f"New user {user_name} created with balance: {initial_balance:.2f}")

    def perform_transaction(self):
        if not self.accounts:
            messagebox.showerror("Error", "No user accounts found. Please create a new user first.")
            return

        user_name = simpledialog.askstring("Transaction", "Enter user name:")
        if user_name not in self.accounts:
            messagebox.showerror("Error", "User not found. Please enter a valid user name.")
            return

        amount = simpledialog.askfloat("Transaction", "Enter amount:")
        transaction_type = simpledialog.askstring("Transaction", "Enter transaction type (DB/CR):").strip().upper()
        date = simpledialog.askstring("Transaction", "Enter date (mmddyy):").strip()
        if amount is not None and transaction_type in ["DB", "CR"] and date:
            self.accounts[user_name].add_transaction(amount, transaction_type, date)
            messagebox.showinfo("Transaction", f"Transaction performed successfully for user {user_name}")

    def check_log(self):
        if not self.accounts:
            messagebox.showerror("Error", "No user accounts found. Please create a new user first.")
            return

        user_name = simpledialog.askstring("Log Book", "Enter user name:")
        if user_name not in self.accounts:
            messagebox.showerror("Error", "User not found. Please enter a valid user name.")
            return

        self.accounts[user_name].apply_service_charges()
        self.accounts[user_name].print_log_book()

if __name__ == "__main__":
    root = tk.Tk()
    app = BankGUI(root)
    root.mainloop()



